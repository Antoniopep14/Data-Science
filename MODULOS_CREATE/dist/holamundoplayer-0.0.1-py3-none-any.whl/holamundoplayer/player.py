"""
Esta es la documentacion de player
"""

class Player:
    """
    Aqui va toda la documentacion de nuestro codigo
    """
    
    def play(self):
        """
        Aqui va la documentacion del metodo, recordar que si
        la documentacion es de una sola linea no es necesario dejar
        el salto de espacio entre las 3 comillas dobles

        Parameter:
        song (str): este es un string con el path de la cancion
        returns: x cosa
        """
        print("reproduciendo cancion")
    
    def stop(self):
        """
        esto detiene la app
        """
        print("stopping")
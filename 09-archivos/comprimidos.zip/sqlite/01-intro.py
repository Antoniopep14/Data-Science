import sqlite3
#primero generamos una conexion con la base 
#de datos usando el metodo con
con = sqlite3.connect("sqlite/app1.db")
#como el archivo no existe, python lo creo
#si no cerramos la conexion a la base de datos
#no vamos a poder excribir en ella despues
#ES MUY IMPORTANTE CERRARLA
con.close()

#marca un error que no pude solucionar asi que dejamos de lado sqlite


from tkinter import *
# para ordenar los elementos de una ventana, la biblioteca de tkinter cuenta con 3 administradores de contenido
# pack: los agrega unos tras otros
# adicionalmente se puede especificar si queremos que el elemento se cargue hacia algun lado
# o llene el ancho o largo de su contenedor
# grid: los ordena en filas y columnas
# place: los posiciona en coordenadas especificas

# una ventana pude tener mas de un administrador de elementos al mismo tiempo
# para facilitar la tarea, se pueden utilizar frames o marcos
# que permiten subdividir un contenedor

r y python mas sql
machine learning, sego varianza, modelos relacionados
algoritmos de la empresa
ML predictivo o supervisado
big data: todo lo relacionado



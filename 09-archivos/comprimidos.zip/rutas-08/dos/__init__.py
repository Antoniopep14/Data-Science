def init(db, api, **_): 
#solamente voy a usar db y api, como no voy a usar el resto de las dependencias uso el poerador de desempaquetamiento **otros
    #si vscode molesta por que otros no esta siendo utilizado podemos reeplazarlo con un _
    print(f"soy modulo dos: {db} {api}") 
def suma(a, b):
    resultado = a + b
    return (resultado)  # cambiamos print por return
# con return podemos obtener el resultado de la funcion
# y asignarlo posteriormente a otra variable


c = suma(2, 3)
d = suma(c, 2)
print(c)
print(d)

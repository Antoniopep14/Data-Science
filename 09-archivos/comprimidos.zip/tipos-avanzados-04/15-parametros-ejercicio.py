# 2 contar en un diccionario cuanto se repiten los caracteres de un atring
# es decir le pasamos un string y nos tiene que devolver un diccionario "a": 2, "b":1, etc
# 3 ordenar las llaves de un diccionario
# por el valor que tienen y deolver una lista
# que contiene tuplas [("a", 3), ("b", 2), ("c", 4), etc]
# 4 de un listado de tuplas
# devolver las tuplas que tengan el mayor valor
# 5 crear un mensaje que diga:
# los caracteres que mas se repitan con x cantidad de repeticiones son:
# y formar una lista con los caracteres mas repetidos (con MAYUS)
# - C
# - D

numero = 2  # entero o integer
decimal = 1.2  # decimal o float
imaginario = 2 + 2j  # 2 + 2i la letra i es la raiz cuadrada de menos 1
# pero en python se escribe con j

print(1 + 3)
print(1 - 3)
print(1 * 3)
print(1 / 3)
print(1 // 3)  # una division con 2 // nos quita los puntos decimales
print(11 % 3)  # arroja lo que sobra de la division 8/3 sobran 2
print(2 ** 3)  # ** es un exponente. 2 elevado a la 3

numero = numero + 2  # estoy reemplazando elvalor de la variable numero
print("numero", numero)
numero += 4  # += indica que le sume el numero a la variable
# el resultado seria 8
# y se puede usar con +=, -=, *=, /=
print(numero)

# el codigo siempre se lee de  arriba hacia abajo y de izq a der
# los nomrbres de variables se escriben con _ no con espacio
# tambien siempre enpiezan con letras no con num, ni simbolos
# variables con dif conbinacion de mayus-minus son difenrentes

nombre_curso = "Ultimate python"
nombre1 = "Hola"
NOMBRE_CURSO = "mundo"
NoMbre_CuRsO = "chachito"
NombreCurso = "feliz"
print(nombre_curso, nombre1, NOMBRE_CURSO)
alumnos = 5000  # integer o entero
puntaje = 89.9  # float o decimal
publicado = False  # boolean


# el lenguaje de programacion es un set de reglas que debe cumplir para considerarse como tal
# lenguaje de alto nivel, es decir que podemos entener cuando vemos el codigo
# implementaciones son el programa que toman el codigo que escribios y lo trasnforman a lenguaje de maquina
# y la implementacion que usamos es cpython que se encuentra escrita en c
# pero tambien hay pypy escrita en python
# jythow escrito en java
# ironpython escrito en c#
# brython para explorador

# para codigo de java pasa por un compilador que se transforma a bytecode
# luego pasa a la JVM o java virtual machine
# y es transformado en lenguaje de maquina

# para python es lo mismo pero pasa por la PVM antes del lenguaje de maquina

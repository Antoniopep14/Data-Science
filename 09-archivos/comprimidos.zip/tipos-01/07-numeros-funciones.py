import math  # esto se escribe para importar las funciones de math
# para ver todas las funciones
print(round(1.3))  # round arroja el numero int mas cercano, 1
print(round(1.5))  # 2
print(abs(-44))  # da el valor absoluto, quita el positivo o negativo, 44
print(math.ceil(1.1))  # da el numero superior entero mas cercano, 2
print(math.floor(1.9))  # da el numero entero mas cercano hacia abajo, 1
print(math.isnan(24))  # dice si el valor no es un numero, Fals
print(math.pow(10, 3))  # eleva algo a una potencia, 1000
print(math.sqrt(9))  # raiz cuadrada, 3

"""Introduccion a python."""  # lo metimos para arreglar el error c0104
# """ """ se usa para definir ciertas lineas y no se ejecuta en el codigo
# "" dentro de () ("") indica un string
print("Hola mundo!")
print("El weta " * 4)
# instalar extensiones desde el menu de la izq de extensiones
# para convertir vscode en un IDE
# la primera es python
# despues pylint que es un linter de microsoft y ayuda a encontrar errores
# despues selecionar el linter presinan shift + ctrl + P
# escogemos pylint que es el mas usado

# numeral se usa para añadir comentarios
# sin miedo a que se ejecute, todo es ignorado
curso = "Ultimate \n\"Python\""
# \anula el sig caracter despues del simbolo y lo vuelve string
# \n toma lo que sigue y lo pasa a una nueva linea
print(curso)

"""introduccion a python"""
# para hacer una aplicacion necesitamos de
# un editor de texto o un IDE
# la funcion print imprime o muestra lo que especifiques
# ()indican una funcion que estamos ejecutando
# por lo que siempre va () despues de una funcion

chanchito = "Feliz"  # esto es una variable y debe tener espacio antes y despues de =
N1 = 12
N2 = 13
print(chanchito, N1, N2)
# se instalo la herramienta format document - autopep8
# la paleta de comandos crtl shift P
# se automatiza pep8 al guardar autamaticamente en config - settings
# despues formatonsave y marcar casilla

# pep8 es un python pep llamado Style Guide for Python Code

edad = 25

if edad >= 15 and edad <= 65:  # no olvidar los : al final para concadenar
    print("puede entrar a la piscina")
# puede escribirse de la sig manera tambien
if 15 <= edad <= 65:  # esto es una cadena de comparadores
    print("puede entrar a la piscina")

n1 = ""
if not n1:
    n1 = input(n1)
# puede usarse para revisar si esa variable existe

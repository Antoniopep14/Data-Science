# comparadosres logicos
# estos siempre van a devolver un boolean

print(1 > 2)
print(1 < 2)
print(1 >= 2)
print(1 <= 2)
print(2 >= 2)
print(2 <= 2)
print(2 == 2)  # se usa == para comparar
print(2 == 3)
print(2 == "2")  # aqui tenemos un int y un string
# por lo que va arrojar False
print(2 != "2")  # Esto significa desigual
print(2 != 2)

n1 = input("ingresa tu edad")
n1 = int(n1)
edad = n1

mensaje = "Es mayor" if edad > 17 else "es menor"

# if edad > 17:
#     mensaje = "es mayor"
# else:
#     mensaje = "es menor"

print(mensaje)  # podriamos hacerlo de la segunda manera
# pero agrega muchas lineas de codigo al programa
